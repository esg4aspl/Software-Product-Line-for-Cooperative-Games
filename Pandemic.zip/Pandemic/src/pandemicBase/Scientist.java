package pandemicBase;

import rules.IRoleCardDescription;

public class Scientist implements IRoleCardDescription {

	@Override
	public void evaluate() {
		// TODO Auto-generated method stub
		
	}

}
