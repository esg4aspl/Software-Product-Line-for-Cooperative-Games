package pandemicBase;

import common.AbstractCard;
import rules.IEventCardResulation;

public class EpidemicCardResulation{

	public void evulate(AbstractCard card) {
		System.out.println("epidemic card resulation");
		
	}

}
