package pandemicBase;

import common.AbstractCard;
import common.Board;
import common.Player;
import rules.IMoveValidation;

public class BuildResearchStitation implements IMoveValidation{ //gibi gibi �teki move'lar da ..

	@Override
	public void evaluate(AbstractCard card, Board board, Player player) {
		// TODO Auto-generated method stub
		
	}

}

