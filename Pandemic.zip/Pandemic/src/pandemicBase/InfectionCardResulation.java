package pandemicBase;

import common.AbstractCard;
import rules.IEventCardResulation;

public class InfectionCardResulation implements IEventCardResulation {

	@Override
	public void evaluate(AbstractCard card) {
		// TODO Auto-generated method stub
		
	}

}
