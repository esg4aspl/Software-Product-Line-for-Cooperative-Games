package pandemicBase;

import common.AbstractCard;
import rules.IEventCardResulation;

public class OneQuietNightEventCard implements IEventCardResulation{ //ve di�er event cardlar�n s�n�flar� yaz�lmal�

	@Override
	public void evaluate(AbstractCard card) {
		// TODO Auto-generated method stub
		
	}

}
