package common;

public abstract class AbstractCard {
	
}
