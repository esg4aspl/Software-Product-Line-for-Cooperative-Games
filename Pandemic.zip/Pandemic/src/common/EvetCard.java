package common;

public class EvetCard extends AbstractCard {

}
