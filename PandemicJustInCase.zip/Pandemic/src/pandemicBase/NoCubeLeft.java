package pandemicBase;

import rules.IEndGameCondition;

public class NoCubeLeft implements IEndGameCondition {

	@Override
	public void evaluate() {
		// TODO Auto-generated method stub
		
	}

}
