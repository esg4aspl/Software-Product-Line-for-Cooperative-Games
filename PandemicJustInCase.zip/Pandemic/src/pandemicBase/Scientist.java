package pandemicBase;

import common.AbstractCard;
import common.RoleCard;
import rules.IRoleCardDescription;

public class Scientist extends RoleCard implements IRoleCardDescription  {

	@Override
	public void evaluate() {
		// TODO Auto-generated method stub
		
	}

}
