package common;

public class EpidemicCard extends AbstractCard {

}
