package common;

public class InfectionCard extends AbstractCard {

}
