package common;
public abstract class AbstractToken extends AbstractGamePieces{

	public AbstractToken(int id) {
		super(id);
	}
	
}
