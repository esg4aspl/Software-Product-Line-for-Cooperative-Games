package common;

public abstract class AbstractMove {
	public abstract  void  doAction(Player player,Board board);
	
}
