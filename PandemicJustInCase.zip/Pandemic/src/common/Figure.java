package common;
public class Figure extends AbstractToken{
	
	public Figure(int ID) {
		super(ID);
	}
}
