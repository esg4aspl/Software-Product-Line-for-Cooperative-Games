package common;

public class DrawCard extends AbstractMove {

	@Override
	public void doAction(Player player,Board board) {
		// TODO Auto-generated method stub
		
	}

}
