package common;
public class Pawn extends AbstractGamePieces {
	
	public Pawn(int ID) {
		super(ID);
	}

}
