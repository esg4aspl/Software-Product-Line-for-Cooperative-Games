package common;
public class Marker extends AbstractToken {

	public Marker(int ID) {
		super(ID);
	}
	
	
}
