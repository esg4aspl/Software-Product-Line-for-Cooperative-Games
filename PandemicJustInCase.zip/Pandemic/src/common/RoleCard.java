package common;

public class RoleCard extends AbstractCard {

}
