package common;

public class DiscardCard extends AbstractMove  {

	@Override
	public void doAction(Player player,Board board) {
		// TODO Auto-generated method stub
		
	}

}
