package rules;

import common.AbstractCard;

public interface IEventCardResulation {
	void evaluate(AbstractCard card);
}
