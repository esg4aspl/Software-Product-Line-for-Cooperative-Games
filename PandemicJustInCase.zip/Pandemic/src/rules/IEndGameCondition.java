package rules;

public interface IEndGameCondition {
	public void evaluate();
}
