package rules;

public interface IRoleCardDescription {
	public void evaluate();
}
