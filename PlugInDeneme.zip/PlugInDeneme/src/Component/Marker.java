package Component;

public class Marker extends Token {

	public Marker(int ID) {
		super(ID);
	}
	
	
}
