package Component;
//Command Deneme - Melek
public class Figure extends Token{
	
	public Figure(int ID) {
		super(ID);
	}
}
