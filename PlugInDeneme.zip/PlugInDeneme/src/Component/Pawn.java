package Component;

public class Pawn extends GamePieces {
	
	public Pawn(int ID) {
		super(ID);
	}

}
