package Component;

public abstract class Token extends GamePieces{

	public Token(int id) {
		super(id);
	}
	
}
